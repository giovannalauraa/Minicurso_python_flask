import sqlite3
from flask import Flask, render_template

app = Flask(__name__)

def get_connection():
    conn = sqlite3.connect('blog.db')
    conn.row_factory = sqlite3.Row
    return conn

def gest_post(post_id):
    conn = get_connection()##continuar aq
    post = conn.execute('SELECT * FROM posts WHERE id = ?', (post_id,)).fetchone()
    conn.close()
    return post

@app.route('/')
def index():
    conn = get_connection()
    posts = conn.execute('SELECT * FROM posts').fetchall()
    conn.close()
    return render_template('index.html', posts=posts)

@app.route('/<int:post_id>')
def post():
    post = get_post(post_id)
    return render_template ('post.html', post=post)